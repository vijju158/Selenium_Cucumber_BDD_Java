package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.runtime.model.CucumberFeature;

import java.io.File;

import org.testng.annotations.*;

import com.cucumber.listener.Reporter;
import com.sun.corba.se.impl.ior.GenericTaggedComponent;

@CucumberOptions(
	
		glue = {"stepdefs"},//Your step definitions package.
		features = {"src/main/java/Features"},
		monochrome = true,
		plugin = {"html:target/cucumber-html-report", "json:target/cucumber-reports/cucumber.json",
				"json:target/cucumber-reports/cucumber.xml",
				"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/advanced-reports/extentreports/extent.html"}
		)

public class TestRunner extends AbstractTestNGCucumberTests {

	@AfterClass
	public static void writeExtentReport() {
		//Reporter.loadXMLConfig(new File("C:\\Users\\Tejas\\OneDrive\\Desktop\\Automation Frameworks\\New\\SeleniumFramework_BDD_TESTNG_JSON-master\\SeleniumFramework_BDD_TESTNG_JSON-master\\eclipse-workspace-1\\PageObject_DataDriven_BDD2\\src\\test\\resources\\extent-config.xml"));  
		Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
	    Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
	    Reporter.setSystemInfo("Machine", 	"Windows 10" + "64 Bit");
	    Reporter.setSystemInfo("Selenium", "3.7.0");
	    Reporter.setSystemInfo("Maven", "3.5.2");
	    Reporter.setSystemInfo("Java Version", "1.8.0_151");
	    Reporter.setTestRunnerOutput("Test Runner Output");
	    
	}
}
