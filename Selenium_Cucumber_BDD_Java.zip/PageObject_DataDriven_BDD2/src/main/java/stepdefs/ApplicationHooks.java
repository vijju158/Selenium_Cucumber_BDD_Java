package stepdefs;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.cucumber.listener.Reporter;
import com.google.common.io.Files;
import com.qa.factory.DriverFactory;
import com.qa.util.ConfigReader;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;



public class ApplicationHooks {

	private DriverFactory driverFactory;
	private WebDriver driver;
	private ConfigReader configReader;
	Properties prop;
	Logger log = Logger.getLogger("devpinoyLogger");


	@Before(order = 0)
	public void getProperty() {
		configReader = new ConfigReader();
		prop = configReader.init_prop();
	}

	@Before(order = 1)
	public void launchBrowser() {
		String browserName = prop.getProperty("browser");
		driverFactory = new DriverFactory();
		driver = driverFactory.init_driver(browserName);
		
	}

	@Before(order = 2)
	public void beforeScenario(Scenario scenario) {
		if (scenario.getName().equals("Test Bank Site Login functionality")) {
			Reporter.assignAuthor("Bank Site - QA Team");
	}
		else {
			Reporter.assignAuthor("QA Team");
		}
	}
		
	@After(order = 0)
	public void quitBrowser() {
		driver.quit();
	}

	
	
	@After(order = 1)
	public void afterScenario(Scenario scenario) {
		if (scenario.isFailed()) {
			String screenshotName = scenario.getName().replaceAll(" ", "_");
			//String screenshotName = scenario.getId();
			try {
				//This takes a screenshot from the driver at save it to the specified location
				File sourcePath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				
				//Building up the destination path for the screenshot to save
				//Also make sure to create a folder 'screenshots' with in the cucumber-report folder
				File destinationPath = new File(System.getProperty("user.dir") + "/target/cucumber-reports/screenshots/" + screenshotName + ".png");
				
				//Copy taken screenshot from source location to destination location
				Files.copy(sourcePath, destinationPath);   

				//This attach the specified screenshot to the test
				System.out.println(destinationPath.toString());
				log.debug(destinationPath.toString());
				Reporter.addScreenCaptureFromPath(destinationPath.toString());
				
			} catch (IOException e) {
			} 
		}
		else {
			Reporter.addScenarioLog("Scenaario :"+"scenario.getName()"+"is Passed");
		}
	}
	
	/*@After(order = 2)
	public void afterScenarioteardown(Scenario scenario) {
		if (scenario.isFailed()) {
	        final byte[] screenshot = ((TakesScreenshot)  DriverFactory.getDriver()).getScreenshotAs(OutputType.BYTES);
	        scenario.embed(screenshot, "image/png");
		}
		else {
			Reporter.addScenarioLog("Scenaario :"+"scenario.getName()"+"is Passed");
		}
	}*/
	
}
