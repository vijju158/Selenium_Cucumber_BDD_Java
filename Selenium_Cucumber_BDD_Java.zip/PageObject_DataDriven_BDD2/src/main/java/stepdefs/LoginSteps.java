package stepdefs;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import static org.assertj.core.api.Assertions.assertThat;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.qa.factory.DriverFactory;

import PageObject.*;
import JSONRead.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;


public class LoginSteps {
	    

	    HomePage objHomePage;
	    private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
	   
	    JSONReader jsonRead = new JSONReader();
	    Logger log = Logger.getLogger("devpinoyLogger");
	@Given("^User navigates to Bank site Login page$")
	public void user_navigates_to_Bank_site_Login_page() throws Throwable {
		 
		    //System.setProperty("webdriver.chrome.driver",".\\Drivers\\chromedriver.exe");
	        //driver = new ChromeDriver();

	        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	        
	        DriverFactory.getDriver().get(jsonRead.jsonRead(".\\Data\\sel.json", "URL"));
	        log.debug("Navigating to Login Page");
	   
	  
	}
	@When("^User enters username & password and clicks login$")
	public void user_enters_username_password_login() throws Throwable {

	
		    //objLogin = new LoginPage(driver);

		    //Verify login page title

		   
		    
		    String loginPageTitle = loginPage.getLoginTitle();

		    Assert.assertTrue(loginPageTitle.toLowerCase().contains(jsonRead.jsonRead(".\\Data\\sel.json", "TITLE")));

		    //login to application

		    objHomePage = loginPage.loginToGuru99(jsonRead.jsonRead(".\\Data\\sel.json", "USER_NAME"), jsonRead.jsonRead(".\\Data\\sel.json", "PASSWORD"));
		    log.debug("Entered the user name and password");
		

	   
	}
	
	@Then("^User should navigate to the home page$")
	public void user_should_navigate_to_the_home_page() throws Throwable {
	

		    //Verify home page

		   assertThat(objHomePage.getHomePageDashboardUserName().toLowerCase()).isEqualTo("manger id : mgr123"); 
		   
		   
		  // assertThat(objHomePage.getHomePageDashboardUserName().toLowerCase()).isEqualTo("manger id : mgr13");
		   
		    	    
		    log.debug("Creating final report");
	
	}

}
