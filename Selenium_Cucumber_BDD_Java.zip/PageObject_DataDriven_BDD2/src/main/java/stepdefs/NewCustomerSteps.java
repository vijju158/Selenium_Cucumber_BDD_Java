package stepdefs;

import java.util.concurrent.TimeUnit;
import static org.assertj.core.api.Assertions.assertThat;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.qa.factory.DriverFactory;

import PageObject.*;
import JSONRead.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;


public class NewCustomerSteps {
	
	    
	    private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
		private HomePage homePage;
	    JSONReader jsonRead = new JSONReader();
	    Logger log = Logger.getLogger("devpinoyLogger");
	@Given("^User logs in to bank Site$")
	public void user_logs_in_to_bank_Site() throws Throwable {
		 
		  DriverFactory.getDriver().get(jsonRead.jsonRead(".\\Data\\sel.json", "URL"));	        
		  homePage = loginPage.loginToGuru99(jsonRead.jsonRead(".\\Data\\sel.json", "USER_NAME"), jsonRead.jsonRead(".\\Data\\sel.json", "PASSWORD"));
	        log.debug("Navigating to Login Page");
	   
	  
	}

		


	
	@Then("^User Clicks on New customer$")
	public void user_Clicks_on_New_customer() throws Throwable {
		homePage.navigateToAddNewCustomerpage();
	
	}

}
